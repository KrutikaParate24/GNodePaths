package com.example;

import java.util.List;

public interface GNode {
    String getName();
    List<GNode> getChildren();
}
